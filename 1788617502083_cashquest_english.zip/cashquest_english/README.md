# CashQuest — English MVP

Open `index.html` in a browser to test the site.

This version is intentionally simple and credible:
- English UI and copy
- no fake testimonials
- no guaranteed income claims
- no external API required
- free quiz with practical result suggestions
- paid-plan section is only a demo until a real checkout is connected

For a public launch, publish `index.html` with a static host such as GitHub Pages, then connect a custom domain later if desired.
